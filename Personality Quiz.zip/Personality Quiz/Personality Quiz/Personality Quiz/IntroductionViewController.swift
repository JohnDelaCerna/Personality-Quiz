// John Kristoffer Dela Cerna
// 10/18/22


import UIKit

class IntroductionViewController: UIViewController {

    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue) {
        //segue is the function that if an action is made it will transition to the next step
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

